package math.classes;

public class MathClasses {

    public static void main(String[] args) {
        // we have many kinds of classes 
        /* there is a class called (Math class):
        by using math class we can execute math operations

         */
     
        System.out.println(Math.sqrt(625));
        System.out.println(Math.pow(2, 4));
        System.out.println(Math.random());
        System.out.println(Math.floor(5.4442));
        System.out.println(Math.ceil(3.76));
        
    }

}
