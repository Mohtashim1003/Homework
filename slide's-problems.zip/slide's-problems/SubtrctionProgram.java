package subtrction.program;

import java.util.Scanner;

public class SubtrctionProgram {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int randomnum1, randomnum2;
        randomnum1 = (int) (Math.random() * 10);
        randomnum2 = (int) (Math.random() * 10);
        int result = (int) randomnum1 - (int) randomnum2;
        int re = randomnum2-randomnum1;
         

        if (randomnum1 >= randomnum2) {
            System.out.println("what is the result of this equation: " + randomnum1 + "-" + randomnum2);
        }else if (randomnum1 < randomnum2){
            System.out.println("what is :"+randomnum2+"-"+randomnum1);
        } 
            int subtraction = input.nextInt();
            if (subtraction == result) {
                System.out.println("true");
            } else if (subtraction== re) {
                System.out.println("true");
            }else{System.out.println("false");}
        }
    }

