
package temperature;
import java.util.Scanner;
public class Temperature {

    
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("inter the temperaure to celsius :" );
        double fahrenheit=input.nextDouble();
        double celsius= (5/9d)*(fahrenheit-32);
        System.out.print("this is the temperatur converted to celsius:  " +celsius);
        
      
    }
    
}
