package lottery;

import java.util.Scanner;

public class Lottery {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int randomnum1 = (int) (Math.random() * 10);
        int randomnum2 = (int) (Math.random() * 10);
        System.out.println("r1: " + randomnum1 + "\n" + "r2: " + randomnum2);
        double input1, input2;
        input1 = input.nextDouble();
        input2 = input.nextDouble();

        if (input1 == randomnum1 && input2 == randomnum2) {
            System.out.println("10000");

        } else if (input1 == randomnum2 && input2 == randomnum1) {
            System.out.println("3000");
        }else if(input1==randomnum1 ^ input2==randomnum2){
            System.out.println("1000");
        }else if (input1== randomnum2 ^ input2==randomnum2){
            System.out.println("1000");
        }else {
            System.out.println("you have lost, you can do it again");
        }

    }
}
