
package example.pkg6;

/**
 *
 * @author mohtashim
 */
public class Example6 {

   
    public static void main(String[] args) {
        double x= 3.293;
        int n= (int)x;
        System.out.println(n);
    }
    
}
