
package example.pkg7;

public class Example7 {

    
    public static void main(String[] args) {
        int x= 15;
        int y=4;
        System.out.println(x%y);
    }
    
}
