
package example.pkg10;

public class Example10 {

   
    public static void main(String[] args) {
      int a,b,c,d;
      a=5;
      b=10;
      c=15;
      d=20;
        boolean and= a<b && a>c;
        System.out.println(and);
        
        boolean or= d>a || c>d;
        System.out.println(or);
        
        boolean not= a!=b;
        System.out.println(not);
        
        boolean exclusiveor = a>b ^ b>a;
        System.out.println(exclusiveor);

    }
    
}
