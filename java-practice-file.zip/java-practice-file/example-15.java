
package roots;
import java.util.Scanner;

public class Roots {

    
    public static void main(String[] args) {
/* in this code: {Scanner input = new Scanner(System.in);} the input is just name
you can put any name here (input is a variable)*/ 
        Scanner input = new Scanner(System.in);
        double a,b,c,root1,root2;
        System.out.println("type a");

        a= input.nextDouble();

        System.out.println("type b");
        
        b= input.nextDouble();
        System.out.println("type c");
         c= input.nextDouble();
        root1=(-b+(Math.sqrt(b*b-4*a*c)))/(2*a);
         root2=(-b-(Math.sqrt(b*b-4*a*c)))/(2*a);
         System.out.println("result root1"+root1+"result root2"+root2);
         
        
         
        
        
        
;
        // TODO code application logic here
    }
    
}
