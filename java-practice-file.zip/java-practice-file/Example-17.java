package example.pkg17;

import java.util.Scanner;

public class Example17 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("here you can enter your desired number and\nspecify whether the number you have enterd is a prime number or not.");
        int number = input.nextInt();

        if ((number % number == 0 && number % 1 == 0) && (number % 2 != 0)) {
            System.out.println("the number you have entered is a prime number");

        }else {
            System.out.println("this number is not a prime number");
        }
    }

}


