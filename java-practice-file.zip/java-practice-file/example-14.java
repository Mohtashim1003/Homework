package loanpayment;

import java.util.Scanner;

public class Loanpayment {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double profit, rate, year, mony;
        System.out.println("inter the mony");
        mony = input.nextDouble();
        System.out.println("inter the rate of profit in percent");
        rate = input.nextDouble();
        System.out.println("inter year");
        year = input.nextDouble();

        profit = (year * rate * mony) / (100);
        System.out.println("profit: "+profit);
        System.out.println("this is your mountly profit: "+profit/12);

    }

}
