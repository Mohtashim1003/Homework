
package example.pkg20.qustoin;


public class Example20Qustoin {

    public static void main(String[] args) {
        
        int x = 5 ;
        System.out.println(x);
        
        
        
    }
    
}
