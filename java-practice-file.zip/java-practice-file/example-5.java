
package example.pkg5;

/**
 *
 * @author mohtashim
 */
public class Example5 {

    public static void main(String[] args) {
        
         String a = "this is";
        String b = "  java";
        System.out.println( a + b);
        
    }
    
}
