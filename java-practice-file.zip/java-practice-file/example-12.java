
package example.pkg12;
import java.util.Scanner;
/**
 *
 * @author mohtashim
 */
public class Example12 {

   
    public static void main(String[] args) {
        Scanner input= new Scanner (System.in);
        
   double r,a;
   final float PI= 3.14f;
        System.out.println("enter the radius to calculate area of the circle.");
   r= input.nextDouble();
   a= r*r*PI;
        System.out.println("the area is: " +a);
   
    }
    
}