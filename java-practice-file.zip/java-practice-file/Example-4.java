
package example.pkg4;

/**
 *
 * @author mohtashim
 */
public class Example4 {

   
    public static void main(String[] args) {
        char x= 'a';
        int num= 100;
        System.out.println(x);
        System.out.println(num);


    }
    
}
