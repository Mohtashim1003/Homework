
package example.pkg9;


public class Example9 {

    public static void main(String[] args) {
        long x= 5;
        x+=2;
        
        int w= 5;
        w-=3;
        
        short r=5;
       r*=2;
       
       byte o=5;
       o/=5;
       
       float c=5;
       c%=4;
        System.out.println(x);
        System.out.println(w);
        System.out.println(r);
        System.out.println(o);
        System.out.println(c);
    }
    
}
